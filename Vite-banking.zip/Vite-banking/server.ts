import express, { Request, Response } from "express";
import cors from "cors";
import BankingDB from "./src/data/bankingDb";

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

function parseAccountId(req: Request, res: Response): number | null {
  const accountId = Number(req.params.accountId);
  if (Number.isNaN(accountId)) {
    res.status(400).json({ error: "Invalid account id" });
    return null;
  }
  return accountId;
}

app.get("/api/account/:accountId", async (req: Request, res: Response) => {
  try {
    const accountId = parseAccountId(req, res);
    if (accountId === null) return;

    const db = await BankingDB.getInstance();
    const account = await db.getAccount(accountId);

    res.json({ account });
  } catch (err) {
    console.error("Error in GET /api/account/:accountId", err);
    res.status(500).json({ error: "Failed to load account" });
  }
});

app.get(
  "/api/account/:accountId/search",
  async (req: Request, res: Response) => {
    try {
      const accountId = parseAccountId(req, res);
      if (accountId === null) return;

      const term = (req.query.term || req.query.q || "").toString().trim();

      const db = await BankingDB.getInstance();
      const account = await db.searchTransactions(accountId, term);

      res.json({ account });
    } catch (err) {
      console.error("Error in GET /api/account/:accountId/search", err);
      res.status(500).json({ error: "Failed to search transactions" });
    }
  }
);

app.post(
  "/api/account/:accountId/deposit",
  async (req: Request, res: Response) => {
    try {
      const accountId = parseAccountId(req, res);
      if (accountId === null) return;

      const { amount, description } = req.body;

      const numericAmount = Math.abs(Number(amount));
      if (!numericAmount || numericAmount <= 0) {
        res
          .status(400)
          .json({ error: "Deposit amount must be a positive number" });
        return;
      }

      const desc = (description || "").toString().trim();
      if (!desc) {
        res.status(400).json({ error: "Description is required" });
        return;
      }

      const db = await BankingDB.getInstance();
      const account = await db.addTransaction(
        accountId,
        "deposit",
        desc,
        numericAmount
      );

      res.json({ account });
    } catch (err) {
      console.error("Error in POST /api/account/:accountId/deposit", err);
      res.status(500).json({ error: "Failed to add deposit" });
    }
  }
);

app.post(
  "/api/account/:accountId/withdrawal",
  async (req: Request, res: Response) => {
    try {
      const accountId = parseAccountId(req, res);
      if (accountId === null) return;

      const { amount, description } = req.body;

      const numericAmount = Math.abs(Number(amount));
      if (!numericAmount || numericAmount <= 0) {
        res
          .status(400)
          .json({ error: "Withdrawal amount must be a positive number" });
        return;
      }

      const desc = (description || "").toString().trim();
      if (!desc) {
        res.status(400).json({ error: "Description is required" });
        return;
      }

      const db = await BankingDB.getInstance();
      const account = await db.addTransaction(
        accountId,
        "withdrawal",
        desc,
        numericAmount
      );

      res.json({ account });
    } catch (err) {
      console.error("Error in POST /api/account/:accountId/withdrawal", err);
      res.status(500).json({ error: "Failed to add withdrawal" });
    }
  }
);

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.listen(PORT, () => {
  console.log(`✔ Banking API running at http://localhost:${PORT}`);
});
