import sqlite3 from "sqlite3";

export interface Account {
  id: number;
  balance: number;
  transactions: Transaction[];
}

export interface Transaction {
  id: number;
  accountId: number;
  date: string;
  description: string;
  amount: number;
}

export default class BankingDB {
  private static instance: BankingDB;
  private db: sqlite3.Database;

  static async getInstance() {
    if (BankingDB.instance) {
      return BankingDB.instance;
    } else {
      const newInstance = new BankingDB();
      await newInstance.setup();

      BankingDB.instance = newInstance;

      return BankingDB.instance;
    }
  }

  private constructor() {
    const fileName = `${process.cwd()}/src/data/bankingDb.db`;

    this.db = new sqlite3.Database(fileName);
  }

  private async setup() {
    await this.execute(`
			CREATE TABLE IF NOT EXISTS accounts (
				id INTEGER PRIMARY KEY,
				balance DECIMAL(10, 2) NOT NULL
			)`);

    await this.execute(`
			CREATE TABLE IF NOT EXISTS transactions (
				id INTEGER PRIMARY KEY,
				accountId INTEGER,
				type TEXT NOT NULL,
				date TEXT NOT NULL,
				description TEXT NOT NULL,
				amount DECIMAL(10, 2) NOT NULL,
				FOREIGN KEY (accountId) REFERENCES accounts(id)
			)`);

    await this.seedData();
  }

  private async seedData() {
    await this.execute(
      `INSERT OR REPLACE INTO accounts (id, balance) VALUES (?, ?)`,
      [1, 1000.0]
    );
  }

  private async execute(sql: string, params: any[] = []) {
    if (params && params.length > 0) {
      return new Promise((resolve, reject) => {
        this.db.run(sql, params, (err) => {
          if (err) reject(err);
          resolve(true);
        });
      });
    } else {
      return new Promise((resolve, reject) => {
        this.db.exec(sql, (err) => {
          if (err) reject(err);
          resolve(true);
        });
      });
    }
  }

  private async fetchAll<T>(sql: string, params: any[] = []): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        resolve(rows as T[]);
      });
    });
  }

  private async fetchFirst<T>(sql: string, params: any[] = []): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);
        if (Array.isArray(row)) {
          resolve([row.shift()] as T[]);
        }
        if (row) {
          resolve([row] as T[]);
        } else {
          resolve([] as T[]);
        }
      });
    });
  }

  async getAccount(accountId: number): Promise<Account> {
    const accounts = await this.fetchFirst<Account>(
      `SELECT * FROM accounts WHERE id = ?`,
      [accountId]
    );

    if (accounts.length === 0) {
      throw new Error(`Account with id ${accountId} not found.`);
    }

    const transactions = await this.fetchAll<Transaction>(
      `SELECT * FROM transactions WHERE accountId = ?`,
      [accountId]
    );
    accounts[0].transactions = transactions;

    return accounts[0];
  }

  async searchTransactions(accountId: number, term: string): Promise<Account> {
    const account = await this.getAccount(accountId);

    const transactions = await this.fetchAll<Transaction>(
      `SELECT * FROM transactions WHERE accountId = ? AND description LIKE ?`,
      [accountId, `%${term}%`]
    );
    account.transactions = transactions;

    return account;
  }

  async addTransaction(
    accountId: number,
    type: string,
    description: string,
    amount: number
  ): Promise<Account> {
    const account = await this.getAccount(accountId);

    if (!["deposit", "withdrawal"].includes(type)) {
      throw new Error(
        `Invalid transaction type: ${type}. Must be deposit or withdrawal.`
      );
    }

    amount = type === "deposit" ? amount : amount * -1;

    const newBalance = account.balance + amount;

    await this.execute(
      `INSERT INTO transactions (accountId, type, date, description, amount) VALUES (?, ?, ?, ?, ?)`,
      [accountId, type, new Date().toISOString(), description, amount]
    );
    await this.execute(`UPDATE accounts SET balance = ? WHERE id = ?`, [
      newBalance,
      accountId,
    ]);

    return this.getAccount(accountId);
  }
}
