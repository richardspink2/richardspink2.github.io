import { Container, Nav, Navbar } from "react-bootstrap";
import { Routes, Route, Link } from "react-router-dom";
import AccountSummary from "./components/AccountSummary";
import AccountTransactions from "./components/AccountTransactions";
import AddTransaction from "./components/AddTransaction";

const ACCOUNT_ID = 1;

function App() {
  return (
    <>
      <Navbar bg="dark" variant="dark" expand="lg">
        <Container>
          <Navbar.Brand as={Link} to="/">
            Banking App
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="main-nav" />
          <Navbar.Collapse id="main-nav">
            <Nav className="me-auto">
              <Nav.Link as={Link} to="/">
                Summary
              </Nav.Link>
              <Nav.Link as={Link} to="/transactions">
                Transactions
              </Nav.Link>
              <Nav.Link as={Link} to="/add">
                Add Transaction
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      <Container className="my-4">
        <Routes>
          <Route path="/" element={<AccountSummary accountId={ACCOUNT_ID} />} />
          <Route
            path="/transactions"
            element={<AccountTransactions accountId={ACCOUNT_ID} />}
          />
          <Route
            path="/add"
            element={<AddTransaction accountId={ACCOUNT_ID} />}
          />
        </Routes>
      </Container>
    </>
  );
}

export default App;
