import { type FormEvent, useEffect, useState } from "react";
import {
  Card,
  Table,
  Spinner,
  Alert,
  Form,
  Button,
  InputGroup,
} from "react-bootstrap";
import type { Account, Transaction } from "../types";

interface AccountTransactionsProps {
  accountId: number;
}

const AccountTransactions: React.FC<AccountTransactionsProps> = ({
  accountId,
}) => {
  const [account, setAccount] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");

  const loadAccount = () => {
    setLoading(true);
    setError("");

    fetch(`/api/account/${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load account");
        return res.json();
      })
      .then((data: { account: Account }) => {
        setAccount(data.account);
        setLoading(false);
      })
      .catch((err: any) => {
        console.error(err);
        setError(err.message || "Error loading account");
        setLoading(false);
      });
  };

  useEffect(() => {
    loadAccount();
  }, [accountId]);

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();

    const term = searchTerm.trim();
    if (!term) {
      loadAccount();
      return;
    }

    setLoading(true);
    setError("");

    fetch(`/api/account/${accountId}/search?term=${encodeURIComponent(term)}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to search transactions");
        return res.json();
      })
      .then((data: { account: Account }) => {
        setAccount(data.account);
        setLoading(false);
      })
      .catch((err: any) => {
        console.error(err);
        setError(err.message || "Error searching transactions");
        setLoading(false);
      });
  };

  if (loading) return <Spinner animation="border" />;
  if (error) return <Alert variant="danger">{error}</Alert>;
  if (!account) return <Alert variant="warning">Account not found.</Alert>;

  const transactions: Transaction[] = [...account.transactions].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <Card>
      <Card.Body>
        <Card.Title>Account Transactions</Card.Title>

        <Form onSubmit={handleSearch} className="my-3">
          <InputGroup>
            <Form.Control
              placeholder="Search by description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <Button type="submit" variant="secondary">
              Search
            </Button>
          </InputGroup>
        </Form>

        <Table striped bordered hover responsive>
          <thead>
            <tr>
              <th>Date</th>
              <th>Type</th>
              <th>Description</th>
              <th className="text-end">Amount</th>
            </tr>
          </thead>
          <tbody>
            {transactions.length === 0 ? (
              <tr>
                <td colSpan={4} className="text-center">
                  No transactions found.
                </td>
              </tr>
            ) : (
              transactions.map((t) => (
                <tr key={t.id}>
                  <td>{new Date(t.date).toLocaleString()}</td>
                  <td>{t.type}</td>
                  <td>{t.description}</td>
                  <td className="text-end">
                    {t.amount < 0 ? "-" : ""}${Math.abs(t.amount).toFixed(2)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </Table>
      </Card.Body>
    </Card>
  );
};

export default AccountTransactions;
