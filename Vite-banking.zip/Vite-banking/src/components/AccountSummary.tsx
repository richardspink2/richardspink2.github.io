import { useEffect, useState } from "react";
import { Card, Table, Spinner, Alert } from "react-bootstrap";
import { type Account, type Transaction } from "../types";

interface AccountSummaryProps {
  accountId: number;
}

const AccountSummary: React.FC<AccountSummaryProps> = ({ accountId }) => {
  const [account, setAccount] = useState<Account | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    setLoading(true);
    setError("");

    fetch(`/api/account/${accountId}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to load account");
        return res.json();
      })
      .then((data: { account: Account }) => {
        setAccount(data.account);
        setLoading(false);
      })
      .catch((err: any) => {
        console.error(err);
        setError(err.message || "Error loading account");
        setLoading(false);
      });
  }, [accountId]);

  if (loading) return <Spinner animation="border" />;
  if (error) return <Alert variant="danger">{error}</Alert>;
  if (!account) return <Alert variant="warning">Account not found.</Alert>;

  const lastFive: Transaction[] = [...account.transactions].slice(-5).reverse();

  return (
    <>
      <Card className="mb-4">
        <Card.Body>
          <Card.Title>Account Summary</Card.Title>
          <Card.Text>
            <strong>Account ID:</strong> {account.id}
          </Card.Text>
          <Card.Text>
            <strong>Current Balance:</strong>{" "}
            <span style={{ color: account.balance < 0 ? "red" : "green" }}>
              ${account.balance.toFixed(2)}
            </span>
          </Card.Text>
        </Card.Body>
      </Card>

      <Card>
        <Card.Body>
          <Card.Title>Last 5 Transactions</Card.Title>
          {lastFive.length === 0 ? (
            <p>No transactions yet.</p>
          ) : (
            <Table striped bordered hover size="sm" className="mt-3">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Type</th>
                  <th>Description</th>
                  <th className="text-end">Amount</th>
                </tr>
              </thead>
              <tbody>
                {lastFive.map((t) => (
                  <tr key={t.id}>
                    <td>{new Date(t.date).toLocaleString()}</td>
                    <td>{t.type}</td>
                    <td>{t.description}</td>
                    <td className="text-end">
                      {t.amount < 0 ? "-" : ""}${Math.abs(t.amount).toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>
    </>
  );
};

export default AccountSummary;
