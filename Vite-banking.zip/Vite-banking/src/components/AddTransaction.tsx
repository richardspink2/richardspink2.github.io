import { type FormEvent, useState } from "react";
import { Card, Form, Button, Alert, Row, Col } from "react-bootstrap";

interface AddTransactionProps {
  accountId: number;
}

const AddTransaction: React.FC<AddTransactionProps> = ({ accountId }) => {
  const [type, setType] = useState<"deposit" | "withdrawal">("deposit");
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setMessage(null);
    setError(null);

    const numericAmount = Number(amount);
    if (!numericAmount || numericAmount <= 0) {
      setError("Amount must be a positive number.");
      return;
    }

    if (!description.trim()) {
      setError("Description is required.");
      return;
    }

    setSubmitting(true);

    fetch(`/api/account/${accountId}/${type}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: numericAmount,
        description: description.trim(),
      }),
    })
      .then(async (res) => {
        if (!res.ok) {
          const body = await res.json().catch(() => ({}));
          throw new Error(body.error || "Failed to add transaction");
        }
        return res.json();
      })
      .then(() => {
        setMessage(
          `Successfully added ${type} of $${numericAmount.toFixed(2)}.`
        );
        setAmount("");
        setDescription("");
      })
      .catch((err: any) => {
        console.error(err);
        setError(err.message || "Failed to add transaction");
      })
      .finally(() => setSubmitting(false));
  };

  return (
    <Card>
      <Card.Body>
        <Card.Title>Add Transaction</Card.Title>

        {message && <Alert variant="success">{message}</Alert>}
        {error && <Alert variant="danger">{error}</Alert>}

        <Form onSubmit={handleSubmit}>
          <Row className="mb-3">
            <Col xs={12} md={4}>
              <Form.Group controlId="type">
                <Form.Label>Type</Form.Label>
                <Form.Select
                  value={type}
                  onChange={(e) =>
                    setType(e.target.value as "deposit" | "withdrawal")
                  }
                >
                  <option value="deposit">Deposit</option>
                  <option value="withdrawal">Withdrawal</option>
                </Form.Select>
              </Form.Group>
            </Col>

            <Col xs={12} md={8}>
              <Form.Group controlId="amount">
                <Form.Label>Amount</Form.Label>
                <Form.Control
                  type="number"
                  step="0.01"
                  min="0"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </Form.Group>
            </Col>
          </Row>

          <Form.Group className="mb-3" controlId="description">
            <Form.Label>Description</Form.Label>
            <Form.Control
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </Form.Group>

          <Button type="submit" disabled={submitting}>
            {submitting ? "Submitting..." : "Submit"}
          </Button>
        </Form>
      </Card.Body>
    </Card>
  );
};

export default AddTransaction;
