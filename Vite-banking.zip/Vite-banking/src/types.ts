export interface Transaction {
  id: number;
  accountId: number;
  type: "deposit" | "withdrawal";
  date: string;
  description: string;
  amount: number; // positive for deposit, negative for withdrawal
}

export interface Account {
  id: number;
  balance: number;
  transactions: Transaction[];
}