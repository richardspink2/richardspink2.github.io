
function passwordStrength(password) {
  let totalPoints = 0;

 
  if (password.length >= 12) {
    totalPoints += 30;
  }

  let hasUppercase = false;
  let hasLowercase = false;
  let hasNumber = false;
  let hasSpecialChar = false;
  const specialChars = "!@#$%^&*()_+{}[]|\\/<>?";
  const numbers = "0123456789";

  
  for (const char of password) {
    if (char >= 'A' && char <= 'Z') {
      hasUppercase = true;
    } else if (char >= 'a' && char <= 'z') {
      hasLowercase = true;
    } else if (numbers.includes(char)) {
      hasNumber = true;
    } else if (specialChars.includes(char)) {
      hasSpecialChar = true;
    }
  }

 
  if (hasUppercase) {
    totalPoints += 10;
  }


  if (hasLowercase) {
    totalPoints += 10;
  }


  if (hasNumber) {
    totalPoints += 10;
  }


  if (hasSpecialChar) {
    totalPoints += 10;
  }


  const lowercasedPassword = password.toLowerCase();
  const containsPassword = lowercasedPassword.includes("password");
  if (containsPassword === false) {
    totalPoints += 30;
  }

  return totalPoints;
}


const userPassword = prompt("Please enter a password to check its strength:");


if (userPassword) {
    const score = passwordStrength(userPassword);

    const strengthLabel = document.querySelector('label[for="strength"]');
    const strengthProgress = document.getElementById('strength');


    strengthLabel.innerHTML = score;
    strengthProgress.value = score;
}
