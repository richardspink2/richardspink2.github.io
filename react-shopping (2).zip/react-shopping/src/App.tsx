import { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import CategoryList from "./components/CategoryList";
import ProductList from "./components/ProductList";
import ProductDetail from "./components/ProductDetail";
import ProductSearch from "./components/ProductSearch";
import Cart from "./components/Cart";
import type { Product } from "./types";

export interface CartEntry {
  product: Product;
  quantity: number;
}

function App() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<number | null>(
    null
  );
  const [searchResults, setSearchResults] = useState<Product[] | null>(null);

  // 🛒 Cart state
  const [cartItems, setCartItems] = useState<CartEntry[]>([]);

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setSelectedProductId(null);
    setSearchResults(null);
  };

  const handleProductSelect = (id: number) => {
    setSelectedProductId(id);
  };

  const handleSearchResults = (products: Product[] | null) => {
    setSearchResults(products);
    setSelectedProductId(null);
  };

  // ➕ Add item to cart
  const handleAddToCart = (product: Product) => {
    setCartItems((prev) => {
      const found = prev.find((entry) => entry.product.id === product.id);

      if (found) {
        // Increase quantity if it already exists
        return prev.map((entry) =>
          entry.product.id === product.id
            ? { ...entry, quantity: entry.quantity + 1 }
            : entry
        );
      }

      // Otherwise add a new cart entry
      return [...prev, { product, quantity: 1 }];
    });
  };

  // ❌ Remove item completely from cart
  const handleRemoveFromCart = (productId: number) => {
    setCartItems((prev) =>
      prev.filter((entry) => entry.product.id !== productId)
    );
  };

  // 🧹 Clear cart
  const handleClearCart = () => {
    setCartItems([]);
  };

  return (
    <Container className="my-4">
      <h1 className="mb-4">Shopping App</h1>

      <Row className="mb-3">
        <Col>
          <ProductSearch onSearchResults={handleSearchResults} />
        </Col>
      </Row>

      <Row>
        <Col xs={12} md={3} className="mb-3">
          <h4>Categories</h4>
          <CategoryList
            onSelectCategory={handleCategorySelect}
            selectedCategory={selectedCategory}
          />
        </Col>

        <Col xs={12} md={5} className="mb-3">
          <h4>
            {searchResults
              ? "Search Results"
              : selectedCategory
              ? `Products in "${selectedCategory}"`
              : "All Products"}
          </h4>
          <ProductList
            category={selectedCategory}
            onSelectProduct={handleProductSelect}
            productsOverride={searchResults}
          />
        </Col>

        <Col xs={12} md={4}>
          <h4>Product Details</h4>
          <ProductDetail
            productId={selectedProductId}
            onAddToCart={handleAddToCart}
          />

          <hr className="my-4" />

          <h4>Your Cart</h4>
          <Cart
            items={cartItems}
            onRemoveItem={handleRemoveFromCart}
            onClearCart={handleClearCart}
          />
        </Col>
      </Row>
    </Container>
  );
}

export default App;
