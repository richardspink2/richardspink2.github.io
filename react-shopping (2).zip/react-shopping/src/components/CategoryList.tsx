import { useEffect, useState } from "react";
import { ListGroup, Spinner, Alert } from "react-bootstrap";

interface CategoryListProps {
  onSelectCategory: (category: string) => void;
  selectedCategory: string | null;
}

const CategoryList: React.FC<CategoryListProps> = ({
  onSelectCategory,
  selectedCategory,
}) => {
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    fetch("/api/categories")
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to load categories");
        }
        return res.json();
      })
      .then((data: string[]) => {
        setCategories(data);
        setLoading(false);
      })
      .catch((err: any) => {
        console.error(err);
        setError(err.message || "Error loading categories");
        setLoading(false);
      });
  }, []);

  if (loading) {
    return <Spinner animation="border" />;
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  return (
    <ListGroup>
      {categories.map((cat) => (
        <ListGroup.Item
          key={cat}
          action
          active={selectedCategory === cat}
          onClick={() => onSelectCategory(cat)}
        >
          {cat}
        </ListGroup.Item>
      ))}
    </ListGroup>
  );
};

export default CategoryList;
