import { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import AddToCartButton from "./AddToCartButton";
import type { Product } from "../types";

interface ProductDetailProps {
  productId: number | null;
  onAddToCart: (product: Product) => void;
}

export default function ProductDetail({
  productId,
  onAddToCart,
}: ProductDetailProps) {
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (!productId) {
      setProduct(null);
      return;
    }

    fetch(`/api/products/${productId}`)
      .then((res) => res.json())
      .then((data: Product) => setProduct(data))
      .catch((err) => {
        console.error("Error fetching product:", err);
        setProduct(null);
      });
  }, [productId]);

  if (!product) {
    return <p>Select a product to view details.</p>;
  }

  return (
    <Card className="p-3 shadow-sm">
      <h5>{product.name}</h5>
      <p className="text-muted">{product.category}</p>
      <p>{product.description}</p>

      <p>
        <strong>Price:</strong> ${product.price.toFixed(2)}
      </p>

      <p>
        <strong>Quantity Available:</strong> {product.quantity}
      </p>

      <AddToCartButton product={product} onAdd={onAddToCart} />
    </Card>
  );
}
