import { Card, ListGroup, Button } from "react-bootstrap";
import type { CartEntry } from "../App";

interface CartProps {
  items: CartEntry[];
  onRemoveItem: (productId: number) => void;
  onClearCart: () => void;
}

export default function Cart({ items, onRemoveItem, onClearCart }: CartProps) {
  const total = items.reduce(
    (sum, entry) => sum + entry.product.price * entry.quantity,
    0
  );

  if (items.length === 0) {
    return <p>Your cart is empty.</p>;
  }

  return (
    <Card className="p-2">
      <ListGroup variant="flush">
        {items.map((entry) => (
          <ListGroup.Item key={entry.product.id}>
            <div className="d-flex justify-content-between align-items-center">
              <div>
                <strong>{entry.product.name}</strong>
                <br />
                Quantity: {entry.quantity}
                <br />
                Price: ${entry.product.price.toFixed(2)} each
                <br />
                Line Total: ${(entry.product.price * entry.quantity).toFixed(2)}
              </div>
              <div>
                <Button
                  variant="outline-danger"
                  size="sm"
                  onClick={() => onRemoveItem(entry.product.id)}
                >
                  Remove
                </Button>
              </div>
            </div>
          </ListGroup.Item>
        ))}
      </ListGroup>

      <div className="d-flex justify-content-between align-items-center mt-3 px-2">
        <strong>Cart Total:</strong>
        <span>${total.toFixed(2)}</span>
      </div>

      <div className="d-flex justify-content-end mt-3 px-2">
        <Button variant="secondary" size="sm" onClick={onClearCart}>
          Clear Cart
        </Button>
      </div>
    </Card>
  );
}
