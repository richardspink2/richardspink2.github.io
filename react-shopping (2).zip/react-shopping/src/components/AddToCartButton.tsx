import { Button } from "react-bootstrap";
import type { Product } from "../types";

interface AddToCartButtonProps {
  product: Product;
  onAdd: (product: Product) => void;
}

export default function AddToCartButton({
  product,
  onAdd,
}: AddToCartButtonProps) {
  return (
    <Button variant="success" onClick={() => onAdd(product)}>
      Add to Cart
    </Button>
  );
}
