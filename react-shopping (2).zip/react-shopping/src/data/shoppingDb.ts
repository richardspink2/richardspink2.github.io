import sqlite3 from "sqlite3";

export interface Product {
  id: number;
  category: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
}

export interface CartItem {
  id: number;
  cartId: number;
  productId: number;
  quantity: number;
}

export default class ShoppingDB {
  private static instance: ShoppingDB;
  private db: sqlite3.Database;
  private productCategories: string[] = [];

  static async getInstance() {
    if (ShoppingDB.instance) {
      return ShoppingDB.instance;
    } else {
      const newInstance = new ShoppingDB();
      await newInstance.setup();

      ShoppingDB.instance = newInstance;

      return ShoppingDB.instance;
    }
  }

  private constructor() {
    const fileName = `${process.cwd()}/src/data/shoppingDb.db`;
    this.db = new sqlite3.Database(fileName);
  }

  private async setup() {
    await this.execute(`
      CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY,
        category TEXT NOT NULL,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        price DECIMAL(10, 2) NOT NULL,
        quantity INTEGER NOT NULL
      )
    `);

    await this.execute(`
      CREATE TABLE IF NOT EXISTS cartItems (
        cartId INTEGER,
        productId INTEGER,
        quantity INTEGER NOT NULL,
        PRIMARY KEY (cartId, productId)
      )
    `);

    await this.seedData();
  }

  private async seedData() {
    for (const product of productData) {
      await this.execute(
        `
        INSERT OR REPLACE INTO products(id, category, name, description, price, quantity)
        VALUES(?, ?, ?, ?, ?, ?)
      `,
        [
          product.id,
          product.category,
          product.name,
          product.description,
          product.price,
          product.quantity,
        ]
      );
    }

    this.productCategories = Array.from(
      new Set(productData.map((p) => p.category))
    ).sort();
  }

  private async execute(sql: string, params: any[] = []) {
    return new Promise((resolve, reject) => {
      if (params && params.length > 0) {
        this.db.run(sql, params, (err) => {
          if (err) reject(err);
          else resolve(true);
        });
      } else {
        this.db.exec(sql, (err) => {
          if (err) reject(err);
          else resolve(true);
        });
      }
    });
  }

  private async fetchAll<T>(sql: string, params: any[] = []): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) reject(err);
        else resolve(rows as T[]);
      });
    });
  }

  private async fetchFirst<T>(sql: string, params: any[] = []): Promise<T[]> {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) reject(err);

        if (!row) return resolve([] as T[]);

        resolve([row as T]);
      });
    });
  }

  async getCategories(): Promise<string[]> {
    return this.productCategories;
  }

  async getAllProducts(): Promise<Product[]> {
    return this.fetchAll<Product>(`SELECT * FROM products`);
  }

  async getProductById(id: number): Promise<Product[]> {
    return this.fetchFirst<Product>(`SELECT * FROM products WHERE id = ?`, [
      id,
    ]);
  }

  async getProductsByCategory(category: string): Promise<Product[]> {
    return this.fetchAll<Product>(`SELECT * FROM products WHERE category = ?`, [
      category,
    ]);
  }

  async searchProductsByName(name: string): Promise<Product[]> {
    return this.fetchAll<Product>(`SELECT * FROM products WHERE name LIKE ?`, [
      `%${name}%`,
    ]);
  }

  async updateProductQuantity(id: number, quantity: number): Promise<void> {
    await this.execute(`UPDATE products SET quantity = ? WHERE id = ?`, [
      quantity,
      id,
    ]);
  }

  async getCart(cartId: number): Promise<CartItem[]> {
    return this.fetchAll<CartItem>(`SELECT * FROM cartItems WHERE cartId = ?`, [
      cartId,
    ]);
  }

  async clearCart(cartId: number): Promise<CartItem[]> {
    await this.execute(`DELETE FROM cartItems WHERE cartId = ?`, [cartId]);
    return this.getCart(cartId);
  }

  async addCartItem(
    cartId: number,
    productId: number,
    quantity: number
  ): Promise<CartItem[]> {
    const products = await this.getProductById(productId);

    if (products.length === 0) {
      throw new Error(`Product with id ${productId} not found.`);
    }

    if (products[0].quantity < quantity) {
      throw new Error(
        `Insufficient quantity for product id ${productId}. Available: ${products[0].quantity}, Requested: ${quantity}`
      );
    }

    const existing = await this.fetchFirst<CartItem>(
      `SELECT * FROM cartItems WHERE cartId = ? AND productId = ?`,
      [cartId, productId]
    );

    if (existing.length > 0) {
      const newQuantity = existing[0].quantity + quantity;
      await this.execute(
        `UPDATE cartItems SET quantity = ? WHERE cartId = ? AND productId = ?`,
        [newQuantity, cartId, productId]
      );
    } else {
      await this.execute(
        `INSERT INTO cartItems (cartId, productId, quantity) VALUES (?, ?, ?)`,
        [cartId, productId, quantity]
      );
    }

    await this.updateProductQuantity(
      productId,
      products[0].quantity - quantity
    );

    return this.getCart(cartId);
  }

  async removeCartItem(
    cartId: number,
    productId: number,
    quantity: number
  ): Promise<CartItem[]> {
    const products = await this.getProductById(productId);

    if (products.length === 0) {
      throw new Error(`Product with id ${productId} not found.`);
    }

    const existing = await this.fetchFirst<CartItem>(
      `SELECT * FROM cartItems WHERE cartId = ? AND productId = ?`,
      [cartId, productId]
    );

    if (existing.length > 0) {
      const newQuantity = existing[0].quantity - quantity;

      if (newQuantity <= 0) {
        await this.execute(
          `DELETE FROM cartItems WHERE cartId = ? AND productId = ?`,
          [cartId, productId]
        );

        await this.updateProductQuantity(
          productId,
          products[0].quantity + existing[0].quantity
        );
      } else {
        await this.execute(
          `UPDATE cartItems SET quantity = ? WHERE cartId = ? AND productId = ?`,
          [newQuantity, cartId, productId]
        );

        await this.updateProductQuantity(
          productId,
          products[0].quantity + quantity
        );
      }
    }

    return this.getCart(cartId);
  }
}

const productData: Product[] = [
  {
    id: 1,
    category: "Food - Frozen Foods",
    name: "Asian Stir-Fry Vegetables",
    description: "Frozen mix of colorful stir-fry veggies.",
    price: 2.99,
    quantity: 92,
  },
  {
    id: 2,
    category: "Food - Snacks",
    name: "Pineapple Coconut Bars",
    description: "Refreshing dessert bars made with pineapple and coconut.",
    price: 3.79,
    quantity: 35,
  },
  {
    id: 3,
    category: "Toys",
    name: "Children's Science Experiment Lab Kit",
    description: "STEM-based kit for kids featuring cool science experiments.",
    price: 29.99,
    quantity: 92,
  },
  {
    id: 4,
    category: "Electronics",
    name: "Wireless HDMI Receiver",
    description: "Stream HD video wirelessly from devices to TV.",
    price: 49.99,
    quantity: 5,
  },
  {
    id: 5,
    category: "Kitchen",
    name: "Snap-On Tupperware Set",
    description: "Durable and versatile food storage containers.",
    price: 34.99,
    quantity: 1,
  },
  {
    id: 6,
    category: "Clothing - Shoes",
    name: "Comfort Flats",
    description: "Everyday flats that combine comfort and style.",
    price: 44.99,
    quantity: 18,
  },
  {
    id: 7,
    category: "Toys",
    name: "Children's Art Set",
    description: "All-in-one art set for kids to unleash creativity.",
    price: 34.99,
    quantity: 73,
  },
  {
    id: 8,
    category: "Toys",
    name: "Interactive Plush Toy",
    description: "Soft, cuddly toy that interacts with children.",
    price: 34.99,
    quantity: 46,
  },
  {
    id: 9,
    category: "Food - Snacks",
    name: "Kettle Corn Popcorn",
    description: "Sweet and salty kettle corn, perfect for snacking.",
    price: 2.99,
    quantity: 50,
  },
  {
    id: 10,
    category: "Computers",
    name: "USB-C Hub",
    description: "Multi-port USB-C hub for connecting devices.",
    price: 39.99,
    quantity: 22,
  },
  {
    id: 11,
    category: "Garden",
    name: "Multi-Purpose Plant Care Tool",
    description: "All-in-one tool for measuring soil moisture, light, and pH.",
    price: 24.99,
    quantity: 47,
  },
  {
    id: 12,
    category: "Food - Grains",
    name: "Whole Wheat Pasta",
    description: "Nutritious and hearty pasta made from whole wheat flour.",
    price: 2.49,
    quantity: 99,
  },
  {
    id: 13,
    category: "Food - Freezer",
    name: "Cauliflower Crust Pizza",
    description: "A gluten-free pizza crust made from cauliflower.",
    price: 7.99,
    quantity: 87,
  },
  {
    id: 14,
    category: "Food - Produce",
    name: "Zucchini",
    description: "Fresh zucchini, versatile for grilling or sautéing.",
    price: 0.79,
    quantity: 76,
  },
  {
    id: 15,
    category: "Kitchen",
    name: "Electric Knife",
    description: "Cordless electric knife for effortless slicing.",
    price: 39.99,
    quantity: 11,
  },
  {
    id: 16,
    category: "Food - Meats",
    name: "Classic Cheeseburger Mix",
    description:
      "All-in-one mix for easy homemade cheeseburgers, just add ground beef.",
    price: 5.49,
    quantity: 64,
  },
  {
    id: 17,
    category: "Food - Grains",
    name: "Couscous",
    description: "Quick-cooking couscous, great as a side or base.",
    price: 2.49,
    quantity: 63,
  },
  {
    id: 18,
    category: "Food - Produce",
    name: "Creamy Coleslaw Mix",
    description: "Shredded cabbage and carrots for coleslaw.",
    price: 2.39,
    quantity: 27,
  },
  {
    id: 19,
    category: "Food - Condiments",
    name: "Almond Butter",
    description: "Creamy almond butter made from roasted almonds.",
    price: 6.49,
    quantity: 45,
  },
  {
    id: 20,
    category: "Food - Grains",
    name: "Mediterranean Couscous",
    description:
      "Flavored couscous with herbs and spices, perfect as a side dish or a base for salads.",
    price: 3.59,
    quantity: 32,
  },
  {
    id: 21,
    category: "Fitness",
    name: "Adjustable Yoga Mat Strap",
    description: "Convenient strap for carrying yoga mats to class.",
    price: 14.99,
    quantity: 46,
  },
  {
    id: 22,
    category: "Accessories",
    name: "Classic Watch",
    description: "Timeless analog watch with a leather strap.",
    price: 99.99,
    quantity: 30,
  },
  {
    id: 23,
    category: "Office",
    name: "Customizable Wall Calendar",
    description: "Personalize your calendar with photos and special dates.",
    price: 24.99,
    quantity: 9,
  },
  {
    id: 24,
    category: "Outdoor",
    name: "Hiking Gaiters",
    description:
      "Protective gaiters to keep dirt and debris out of shoes during hikes.",
    price: 29.99,
    quantity: 27,
  },
  {
    id: 25,
    category: "Kitchen",
    name: "Pasta Maker",
    description: "Manual pasta maker for homemade pasta.",
    price: 39,
    quantity: 97,
  },
  {
    id: 26,
    category: "Kitchen",
    name: "Multi-Cooker",
    description:
      "Versatile multi-cooker for pressure cooking and slow cooking.",
    price: 89.99,
    quantity: 39,
  },
  {
    id: 27,
    category: "Garden",
    name: "Multi-Purpose Plant Care Tool",
    description: "All-in-one tool for measuring soil moisture, light, and pH.",
    price: 24.99,
    quantity: 53,
  },
  {
    id: 28,
    category: "Toys",
    name: "Magnetic Chess Set",
    description: "Portable chess set with magnetic pieces for travel.",
    price: 19.99,
    quantity: 40,
  },
  {
    id: 29,
    category: "Food - Snacks",
    name: "Roasted Chickpeas",
    description: "Crispy roasted chickpeas seasoned to perfection",
    price: 2.99,
    quantity: 1,
  },
  {
    id: 30,
    category: "Food - Baking",
    name: "Coconut Flakes",
    description: "Unsweetened coconut flakes for baking and topping.",
    price: 3.29,
    quantity: 46,
  },
  {
    id: 31,
    category: "Clothing - Tops",
    name: "Classic White T-Shirt",
    description:
      "A timeless wardrobe staple crafted from soft cotton with a perfect fit.",
    price: 19.99,
    quantity: 27,
  },
  {
    id: 32,
    category: "Outdoor",
    name: "Portable Hammock Swing",
    description:
      "Lightweight and portable swing hammock for relaxing outdoors.",
    price: 59.99,
    quantity: 66,
  },
  {
    id: 33,
    category: "Food - Desserts",
    name: "Classic Vanilla Fudge",
    description: "Creamy vanilla fudge, a sweet treat for all occasions.",
    price: 4.49,
    quantity: 58,
  },
  {
    id: 34,
    category: "Food - Produce",
    name: "Carrot and Celery Sticks",
    description: "Fresh pre-cut carrot and celery sticks for easy snacking.",
    price: 2.99,
    quantity: 3,
  },
  {
    id: 35,
    category: "Outdoor",
    name: "Portable Camping Stove",
    description: "Compact camp stove for outdoor cooking.",
    price: 49.99,
    quantity: 70,
  },
  {
    id: 36,
    category: "Food - Prepared Foods",
    name: "Chicken Salad Kit",
    description: "All-in-one kit for making delicious chicken salad.",
    price: 5.99,
    quantity: 61,
  },
  {
    id: 37,
    category: "Pets",
    name: "Pet First Aid Kit",
    description:
      "Essential kit for taking care of your pets' health emergencies.",
    price: 29.99,
    quantity: 8,
  },
  {
    id: 38,
    category: "Food - Baking & Cooking",
    name: "Almond Flour Tortillas",
    description:
      "Gluten-free tortillas made from almond flour, perfect for various wraps and meals.",
    price: 4.99,
    quantity: 29,
  },
  {
    id: 39,
    category: "Home",
    name: "Memory Foam Mattress Topper",
    description: "3-inch memory foam mattress topper for added comfort.",
    price: 109.99,
    quantity: 13,
  },
  {
    id: 40,
    category: "Food - Snacks",
    name: "Cinnamon Roll Protein Bar",
    description: "Soft and chewy bar packed with protein and cinnamon flavors.",
    price: 2.99,
    quantity: 8,
  },
  {
    id: 41,
    category: "Food - Meat",
    name: "Oven-Baked Chicken Tenders",
    description: "Crispy and juicy chicken tenders, perfect for dipping.",
    price: 6.99,
    quantity: 1,
  },
  {
    id: 42,
    category: "Food - Dairy",
    name: "Ricotta Cheese",
    description: "Creamy ricotta cheese, great for cooking or making desserts.",
    price: 4.99,
    quantity: 22,
  },
  {
    id: 43,
    category: "Food - Meat Alternatives",
    name: "Tofu",
    description: "Firm tofu, a great plant-based protein option.",
    price: 2.49,
    quantity: 97,
  },
  {
    id: 44,
    category: "Home",
    name: "Woven Storage Baskets",
    description: "Stylish baskets for organizing various items in your home.",
    price: 24.99,
    quantity: 11,
  },
  {
    id: 45,
    category: "Food - Cereals",
    name: "Raisin Cinnamon Granola",
    description:
      "Crunchy granola with raisins and cinnamon for a delightful breakfast.",
    price: 3.79,
    quantity: 22,
  },
  {
    id: 46,
    category: "Food - Condiments",
    name: "Poppy Seed Dressing",
    description:
      "A light and tangy dressing with poppy seeds, perfect for salads.",
    price: 3.49,
    quantity: 31,
  },
  {
    id: 47,
    category: "Kitchen",
    name: "Multi-Function Meat Tenderizer",
    description: "Kitchen tool for tenderizing meat to enhance flavors.",
    price: 19.99,
    quantity: 75,
  },
  {
    id: 48,
    category: "Food - Canned Soups",
    name: "Homestyle Beef Stew",
    description: "Hearty beef stew with vegetables, ready to heat and serve.",
    price: 7.99,
    quantity: 31,
  },
  {
    id: 49,
    category: "Kitchen",
    name: "Personalized Cutting Board",
    description: "Custom cutting board made from high-quality wood.",
    price: 34.99,
    quantity: 18,
  },
  {
    id: 50,
    category: "Food - Sauces",
    name: "Coconut Curry Sauce",
    description: "A flavorful sauce made with coconut milk and spices.",
    price: 3.89,
    quantity: 38,
  },
  {
    id: 51,
    category: "Travel",
    name: "Travel Shoe Bags Set",
    description: "Set of breathable bags for organizing shoes while traveling.",
    price: 15.99,
    quantity: 65,
  },
  {
    id: 52,
    category: "Food - Condiments",
    name: "Thai Coconut Curry Sauce",
    description:
      "A rich coconut curry sauce perfect for simmering vegetables or meats.",
    price: 3.99,
    quantity: 70,
  },
  {
    id: 53,
    category: "Outdoor",
    name: "Solar Garden Lights",
    description:
      "Energy-efficient lights that charge during the day and illuminate at night.",
    price: 39.99,
    quantity: 24,
  },
  {
    id: 54,
    category: "Food - Frozen Foods",
    name: "Frozen Berry Blend",
    description: "A mix of frozen berries for smoothies or desserts",
    price: 4.99,
    quantity: 6,
  },
  {
    id: 55,
    category: "Toys",
    name: "Puzzle Mat",
    description: "Foldable mat for jigsaw puzzle assembly.",
    price: 22.99,
    quantity: 19,
  },
  {
    id: 56,
    category: "Food - Frozen Foods",
    name: "Cauliflower Rice Stir-Fry",
    description:
      "Frozen cauliflower rice blended with mixed vegetables and seasonings.",
    price: 4.99,
    quantity: 82,
  },
  {
    id: 57,
    category: "Health",
    name: "Foot Massager Machine",
    description: "Electric foot massager for relaxation and relief.",
    price: 59.99,
    quantity: 89,
  },
  {
    id: 58,
    category: "Food - Condiments",
    name: "Salsa",
    description: "Fresh and zesty salsa, perfect for nachos.",
    price: 3.49,
    quantity: 66,
  },
  {
    id: 59,
    category: "Food - Deli",
    name: "Spinach Feta Wraps",
    description: "Whole wheat wraps filled with spinach, feta, and herbs.",
    price: 4.29,
    quantity: 60,
  },
  {
    id: 60,
    category: "Kitchen",
    name: "Plant-Based Meal Prep Containers",
    description: "Eco-friendly meal prep containers for healthy eating.",
    price: 18.99,
    quantity: 40,
  },
  {
    id: 61,
    category: "Food - Produce",
    name: "Organic Spinach",
    description: "Fresh organic spinach, great for salads or cooking.",
    price: 2.99,
    quantity: 81,
  },
  {
    id: 62,
    category: "Electronics",
    name: "Smartphone Projector",
    description:
      "DIY projector that magnifies your smartphone screen for movie nights.",
    price: 29.99,
    quantity: 98,
  },
  {
    id: 63,
    category: "Food - Salads",
    name: "Black Bean & Corn Salad",
    description:
      "A fresh salad made with black beans, corn, and a zesty dressing, great for summer cookouts.",
    price: 3.99,
    quantity: 58,
  },
  {
    id: 64,
    category: "Food - Snacks",
    name: "Pumpkin Seeds",
    description: "Crunchy roasted pumpkin seeds, great for snacking.",
    price: 2.79,
    quantity: 41,
  },
  {
    id: 65,
    category: "Accessories",
    name: "Phone Screen Protector",
    description: "Tempered glass screen protector for smartphones.",
    price: 12.99,
    quantity: 36,
  },
  {
    id: 66,
    category: "Food - Fresh Produce",
    name: "Fresh Lemons",
    description: "Citrusy lemons perfect for drinks and cooking.",
    price: 0.75,
    quantity: 97,
  },
  {
    id: 67,
    category: "Kitchen",
    name: "Magnetic Spice Jars",
    description: "Convenient magnetic jars for easy spice storage.",
    price: 24.99,
    quantity: 12,
  },
  {
    id: 68,
    category: "Kitchen",
    name: "Ice Cream Maker",
    description: "Homemade ice cream maker for delicious desserts.",
    price: 79.99,
    quantity: 71,
  },
  {
    id: 69,
    category: "Outdoor",
    name: "Hiking Water Bottle with Filter",
    description:
      "8oz water bottle with built-in filter for clean drinking water.",
    price: 29.99,
    quantity: 40,
  },
  {
    id: 70,
    category: "Footwear",
    name: "Hiking Boots",
    description: "Comfortable hiking boots for outdoor adventures.",
    price: 79.99,
    quantity: 79,
  },
  {
    id: 71,
    category: "Food - Cereal",
    name: "Granola Clusters",
    description:
      "Crunchy granola clusters, perfect for snacking or topping yogurt.",
    price: 4.99,
    quantity: 11,
  },
  {
    id: 72,
    category: "Food - Frozen Foods",
    name: "Vegetable Pizza Rolls",
    description:
      "Frozen pizza rolls filled with vegetables and cheese, perfect for snacks.",
    price: 6.49,
    quantity: 82,
  },
  {
    id: 73,
    category: "Pets",
    name: "Pet Hair Vacuum Cleaner Attachment",
    description: "Specialized attachment for removing pet hair from surfaces.",
    price: 14.99,
    quantity: 50,
  },
  {
    id: 74,
    category: "Home",
    name: "Bamboo Bathtub Caddy",
    description:
      "Expandable caddy for holding books, phones, and snacks while in the bath.",
    price: 34.99,
    quantity: 89,
  },
  {
    id: 75,
    category: "Home",
    name: "Fall-Themed Table Runner",
    description: "Decorative table runner perfect for autumn gatherings.",
    price: 19.99,
    quantity: 6,
  },
  {
    id: 76,
    category: "Food - Prepared Meals",
    name: "Basil Pesto Pasta",
    description: "Pasta tossed with fresh basil pesto, simple and delicious.",
    price: 6.49,
    quantity: 14,
  },
  {
    id: 77,
    category: "Food - Confectionery",
    name: "Coconut Macaroons",
    description: "Chewy cookies made with coconut, perfect for sweet cravings.",
    price: 4.99,
    quantity: 34,
  },
  {
    id: 78,
    category: "Fitness",
    name: "High-Quality Yoga Block",
    description: "Foam yoga block for enhancing poses and stability.",
    price: 12.99,
    quantity: 62,
  },
  {
    id: 79,
    category: "Kitchen",
    name: "Dish Soap Dispenser",
    description: "Stylish dish soap dispenser with sponge holder.",
    price: 18.99,
    quantity: 44,
  },
  {
    id: 80,
    category: "Food - Grains",
    name: "Red Lentils",
    description: "Nutritious and quick-cooking red lentils.",
    price: 1.99,
    quantity: 18,
  },
  {
    id: 81,
    category: "Outdoor",
    name: "Folding Table",
    description: "Portable folding table for outdoor events.",
    price: 59.99,
    quantity: 25,
  },
  {
    id: 82,
    category: "Kitchen",
    name: "Multi-Layer Food Steamer",
    description:
      "Stackable steamers for healthy cooking of vegetables and seafood.",
    price: 39.99,
    quantity: 2,
  },
  {
    id: 83,
    category: "Food - Snacks",
    name: "Dried Fruit Medley",
    description: "A delightful mix of dried fruits for trail mix or snacks.",
    price: 5.49,
    quantity: 3,
  },
  {
    id: 84,
    category: "Food - Frozen Meals",
    name: "Chicken Parmesan Dinner Kit",
    description:
      "A complete meal kit containing breaded chicken breast, marinara sauce, and pasta, perfect for a quick dinner.",
    price: 14.99,
    quantity: 78,
  },
  {
    id: 85,
    category: "Food - Prepared Meals",
    name: "Spicy Tuna Sushi Kit",
    description:
      "Everything you need to make delicious spicy tuna rolls at home.",
    price: 8.99,
    quantity: 89,
  },
  {
    id: 86,
    category: "Food - Breakfast",
    name: "Savory Oats",
    description: "Instant oats with a savory twist, such as herbs and spices.",
    price: 2.49,
    quantity: 19,
  },
  {
    id: 87,
    category: "Kitchen",
    name: "Electric Griddle with Lid",
    description: "Non-stick griddle for pancakes, burgers, and more.",
    price: 49.99,
    quantity: 39,
  },
  {
    id: 88,
    category: "Food - Dairy",
    name: "Garlic Herb Cream Cheese",
    description: "Spreadable cream cheese blended with garlic and herbs.",
    price: 2.99,
    quantity: 34,
  },
  {
    id: 89,
    category: "Kitchen",
    name: "Ceramic Cookware Set",
    description: "Durable and non-stick ceramic cookware for healthy cooking.",
    price: 179.99,
    quantity: 74,
  },
  {
    id: 90,
    category: "Outdoor",
    name: "Reversible Swimming Pool Lounger",
    description: "Floating lounger for relaxation in swimming pools or lakes.",
    price: 34.99,
    quantity: 47,
  },
  {
    id: 91,
    category: "Food - Snacks",
    name: "Nutty Trail Mix",
    description: "A blend of nuts, seeds, and dried fruits for snacking.",
    price: 4.29,
    quantity: 36,
  },
  {
    id: 92,
    category: "Food - Beverages",
    name: "Pumpkin Spice Creamer",
    description:
      "A seasonal creamer that adds pumpkin spice flavor to coffee or tea.",
    price: 3.79,
    quantity: 31,
  },
  {
    id: 93,
    category: "Clothing",
    name: "Luxury Bath Robe",
    description: "Soft and plush robe for comfort after the shower.",
    price: 49.99,
    quantity: 78,
  },
  {
    id: 94,
    category: "Clothing - Footwear",
    name: "Waterproof Rain Boots",
    description: "Stay dry with these stylish waterproof rain boots.",
    price: 69.99,
    quantity: 40,
  },
  {
    id: 95,
    category: "Food - Frozen",
    name: "Frozen Acai Purée",
    description: "Unsweetened frozen acai purée for smoothies and bowls.",
    price: 6.99,
    quantity: 26,
  },
  {
    id: 96,
    category: "Kitchen",
    name: "Eco-Friendly Disposable Plates",
    description: "Compostable plates suitable for various occasions.",
    price: 22.99,
    quantity: 91,
  },
  {
    id: 97,
    category: "Food - Grains",
    name: "Basmati Rice",
    description: "Aromatic long-grain basmati rice, perfect for curries.",
    price: 5.79,
    quantity: 67,
  },
  {
    id: 98,
    category: "Kitchen",
    name: "Mini Food Processor",
    description: "Compact food processor for quick meal prep.",
    price: 39.99,
    quantity: 90,
  },
  {
    id: 99,
    category: "Toys",
    name: "Children's Musical Instrument Set",
    description: "Fun instruments to introduce kids to music.",
    price: 39.99,
    quantity: 47,
  },
  {
    id: 100,
    category: "Home",
    name: "Throw Pillow Covers",
    description: "Set of decorative pillow covers to enhance your home decor.",
    price: 22.99,
    quantity: 65,
  },
];
