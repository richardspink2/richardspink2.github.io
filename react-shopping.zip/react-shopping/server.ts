import express, { type Request, type Response } from "express";
import cors from "cors";
import ShoppingDB from "./src/data/shoppingDb";

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

app.use((req, _res, next) => {
  console.log(`${req.method} ${req.path}`);
  next();
});

app.get("/api/hello", (_req: Request, res: Response) => {
  res.json({ message: "Hello from Express + SQLite!" });
});

app.get("/api/categories", async (_req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const categories = await db.getCategories();
    res.json(categories);
  } catch (err) {
    console.error("Error getting categories:", err);
    res.status(500).json({ error: "Failed to load categories" });
  }
});

app.get("/api/products/search", async (req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const name = (req.query.name || "").toString();
    const products = await db.searchProductsByName(name);
    res.json(products);
  } catch (err) {
    console.error("Error searching products:", err);
    res.status(500).json({ error: "Failed to search products" });
  }
});

app.get("/api/products", async (_req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const products = await db.getAllProducts();
    res.json(products);
  } catch (err) {
    console.error("Error getting products:", err);
    res.status(500).json({ error: "Failed to load products" });
  }
});

app.get("/api/products/:id", async (req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const id = Number(req.params.id);

    if (Number.isNaN(id)) {
      return res.status(400).json({ error: "Invalid product id" });
    }

    const products = await db.getProductById(id);

    if (!products || products.length === 0) {
      return res.status(404).json({ error: "Product not found" });
    }

    res.json(products[0]);
  } catch (err) {
    console.error("Error getting product by id:", err);
    res.status(500).json({ error: "Failed to load product" });
  }
});

app.get(
  "/api/categories/:category/products",
  async (req: Request, res: Response) => {
    try {
      const db = await ShoppingDB.getInstance();
      const category = req.params.category;
      const products = await db.getProductsByCategory(category);
      res.json(products);
    } catch (err) {
      console.error("Error getting products by category:", err);
      res.status(500).json({ error: "Failed to load products for category" });
    }
  }
);

app.get("/api/cart/:cartId", async (req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const cartId = Number(req.params.cartId);

    if (Number.isNaN(cartId)) {
      return res.status(400).json({ error: "Invalid cart id" });
    }

    const items = await db.getCart(cartId);
    res.json(items);
  } catch (err) {
    console.error("Error getting cart:", err);
    res.status(500).json({ error: "Failed to load cart" });
  }
});

app.delete("/api/cart/:cartId", async (req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const cartId = Number(req.params.cartId);

    if (Number.isNaN(cartId)) {
      return res.status(400).json({ error: "Invalid cart id" });
    }

    const items = await db.clearCart(cartId);
    res.json(items);
  } catch (err) {
    console.error("Error clearing cart:", err);
    res.status(500).json({ error: "Failed to clear cart" });
  }
});

app.post("/api/cart/:cartId/items", async (req: Request, res: Response) => {
  try {
    const db = await ShoppingDB.getInstance();
    const cartId = Number(req.params.cartId);
    const { productId, quantity } = req.body;

    if (Number.isNaN(cartId) || !productId || !quantity) {
      return res
        .status(400)
        .json({ error: "cartId, productId and quantity are required" });
    }

    const items = await db.addCartItem(
      cartId,
      Number(productId),
      Number(quantity)
    );
    res.json(items);
  } catch (err: any) {
    console.error("Error adding cart item:", err);
    res.status(500).json({ error: err.message || "Failed to add cart item" });
  }
});

app.delete(
  "/api/cart/:cartId/items/:productId",
  async (req: Request, res: Response) => {
    try {
      const db = await ShoppingDB.getInstance();
      const cartId = Number(req.params.cartId);
      const productId = Number(req.params.productId);
      const qty = Number(req.query.quantity ?? 1);

      if (Number.isNaN(cartId) || Number.isNaN(productId)) {
        return res.status(400).json({ error: "Invalid cartId or productId" });
      }

      const items = await db.removeCartItem(cartId, productId, qty);
      res.json(items);
    } catch (err: any) {
      console.error("Error removing cart item:", err);
      res
        .status(500)
        .json({ error: err.message || "Failed to remove cart item" });
    }
  }
);

app.listen(PORT, () => {
  console.log(`✔ Server running at http://localhost:${PORT}`);
});
