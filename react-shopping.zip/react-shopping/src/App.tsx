import { useState } from "react";
import { Container, Row, Col, Button, Modal, ListGroup } from "react-bootstrap";
import CategoryList from "./components/CategoryList";
import ProductList from "./components/ProductList";
import ProductDetail from "./components/ProductDetail";
import ProductSearch from "./components/ProductSearch";
import type { Product } from "./types";

function App() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedProductId, setSelectedProductId] = useState<number | null>(
    null
  );
  const [searchResults, setSearchResults] = useState<Product[] | null>(null);

  const [cart, setCart] = useState<{ product: Product; quantity: number }[]>(
    []
  );
  const [showCart, setShowCart] = useState(false);

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const found = prev.find((item) => item.product.id === product.id);
      if (found) {
        return prev.map((item) =>
          item.product.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
  };

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setSelectedProductId(null);
    setSearchResults(null);
  };

  const handleProductSelect = (id: number) => {
    setSelectedProductId(id);
  };

  const handleSearchResults = (products: Product[] | null) => {
    setSearchResults(products);
    setSelectedProductId(null);
  };

  const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <Container className="my-4">
      <Row className="mb-3">
        <Col>
          <h1>Shopping App</h1>
        </Col>

        {/* 🛒 VIEW CART BUTTON */}
        <Col className="text-end">
          <Button variant="primary" onClick={() => setShowCart(true)}>
            View Cart ({totalItems})
          </Button>
        </Col>
      </Row>

      <Row className="mb-3">
        <Col>
          <ProductSearch onSearchResults={handleSearchResults} />
        </Col>
      </Row>

      <Row>
        <Col xs={12} md={3} className="mb-3">
          <h4>Categories</h4>
          <CategoryList
            onSelectCategory={handleCategorySelect}
            selectedCategory={selectedCategory}
          />
        </Col>

        <Col xs={12} md={5} className="mb-3">
          <h4>
            {searchResults
              ? "Search Results"
              : selectedCategory
              ? `Products in "${selectedCategory}"`
              : "All Products"}
          </h4>

          <ProductList
            category={selectedCategory}
            onSelectProduct={handleProductSelect}
            productsOverride={searchResults}
          />
        </Col>

        <Col xs={12} md={4}>
          <h4>Product Details</h4>
          <ProductDetail
            productId={selectedProductId}
            onAddToCart={handleAddToCart}
          />
        </Col>
      </Row>

      {/* 🛒 CART MODAL */}
      <Modal show={showCart} onHide={() => setShowCart(false)}>
        <Modal.Header closeButton>
          <Modal.Title>Your Cart</Modal.Title>
        </Modal.Header>

        <Modal.Body>
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            <ListGroup>
              {cart.map((item) => (
                <ListGroup.Item key={item.product.id}>
                  <strong>{item.product.name}</strong>
                  <br />
                  Quantity: {item.quantity}
                  <br />
                  Price: ${(item.product.price * item.quantity).toFixed(2)}
                </ListGroup.Item>
              ))}
            </ListGroup>
          )}
        </Modal.Body>

        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowCart(false)}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
}

export default App;
