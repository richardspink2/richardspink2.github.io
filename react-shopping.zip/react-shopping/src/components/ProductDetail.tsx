import { useEffect, useState } from "react";
import { Card, Button } from "react-bootstrap";
import type { Product } from "../types";

interface Props {
  productId: number | null;
  onAddToCart: (product: Product) => void;
}

export default function ProductDetail({ productId, onAddToCart }: Props) {
  const [product, setProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (!productId) {
      setProduct(null);
      return;
    }

    fetch(`/api/products/${productId}`)
      .then((res) => res.json())
      .then((data) => setProduct(data));
  }, [productId]);

  if (!product) return <p>Select a product.</p>;

  return (
    <Card className="p-3 shadow-sm">
      <h5>{product.name}</h5>
      <p className="text-muted">{product.category}</p>
      <p>{product.description}</p>

      <p>
        <strong>Price:</strong> ${product.price.toFixed(2)}
      </p>

      <p>
        <strong>Quantity Available:</strong> {product.quantity}
      </p>

      <Button variant="success" onClick={() => onAddToCart(product)}>
        Add to Cart
      </Button>
    </Card>
  );
}
