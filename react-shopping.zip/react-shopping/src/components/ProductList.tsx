import { useEffect, useState } from "react";
import { Card, Button, Spinner, Alert, Row, Col } from "react-bootstrap";
import { type Product } from "../types";

interface ProductListProps {
  category: string | null;
  onSelectProduct: (productId: number) => void;
  productsOverride?: Product[] | null;
}

const ProductList: React.FC<ProductListProps> = ({
  category,
  onSelectProduct,
  productsOverride = null,
}) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (productsOverride !== null) {
      setProducts(productsOverride);
      setError("");
      setLoading(false);
      return;
    }

    setLoading(true);
    setError("");

    const url =
      category && category.trim().length > 0
        ? `/api/categories/${encodeURIComponent(category)}/products`
        : "/api/products";

    fetch(url)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to load products");
        }
        return res.json();
      })
      .then((data: Product[]) => {
        setProducts(data);
        setLoading(false);
      })
      .catch((err: any) => {
        console.error("ProductList fetch error:", err);
        setError(err.message || "Error loading products");
        setLoading(false);
      });
  }, [category, productsOverride]);

  if (loading) {
    return <Spinner animation="border" />;
  }

  if (error) {
    return <Alert variant="danger">{error}</Alert>;
  }

  if (products.length === 0) {
    return <p>No products found.</p>;
  }

  return (
    <Row className="g-3">
      {products.map((p) => (
        <Col key={p.id} xs={12} md={6} lg={4}>
          <Card>
            <Card.Body>
              <Card.Title>{p.name}</Card.Title>
              <Card.Subtitle className="mb-2 text-muted">
                {p.category}
              </Card.Subtitle>
              <Card.Text>{p.description}</Card.Text>
              <Card.Text>
                <strong>${p.price.toFixed(2)}</strong> — In stock: {p.quantity}
              </Card.Text>
              <Button variant="primary" onClick={() => onSelectProduct(p.id)}>
                View Details
              </Button>
            </Card.Body>
          </Card>
        </Col>
      ))}
    </Row>
  );
};

export default ProductList;
