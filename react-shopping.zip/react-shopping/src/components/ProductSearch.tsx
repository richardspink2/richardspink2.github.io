import { type FormEvent, useState } from "react";
import { Form, Button, InputGroup } from "react-bootstrap";
import type { Product } from "../types";

interface ProductSearchProps {
  onSearchResults: (products: Product[] | null) => void;
}

const ProductSearch: React.FC<ProductSearchProps> = ({ onSearchResults }) => {
  const [term, setTerm] = useState("");

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();

    const trimmed = term.trim();
    if (!trimmed) {
      onSearchResults(null);
      return;
    }

    fetch(`/api/products/search?name=${encodeURIComponent(trimmed)}`)
      .then((res) => {
        if (!res.ok) {
          throw new Error("Failed to search products");
        }
        return res.json();
      })
      .then((data: Product[]) => {
        onSearchResults(data);
      })
      .catch((err) => {
        console.error("Search error:", err);
        onSearchResults([]);
      });
  };

  return (
    <Form onSubmit={handleSubmit} className="mb-3">
      <InputGroup>
        <Form.Control
          type="text"
          placeholder="Search products..."
          value={term}
          onChange={(e) => setTerm(e.target.value)}
        />
        <Button type="submit" variant="secondary">
          Search
        </Button>
      </InputGroup>
    </Form>
  );
};

export default ProductSearch;
