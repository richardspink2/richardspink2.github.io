import React from "react";

export interface ForecastDayProps {
  date: string;
  condition: string;
  highTemp: number;
  lowTemp: number;
  icon: string;
}

const ForecastDay: React.FC<ForecastDayProps> = ({
  date,
  condition,
  highTemp,
  lowTemp,
  icon,
}) => {
  return (
    <div className="forecast-card">
      <h3>{date}</h3>
      <img src={icon} alt={condition} />
      <p className="condition">Condition: {condition}</p>
      <p>High: {highTemp}°F</p>
      <p>Low: {lowTemp}°F</p>
    </div>
  );
};

export default ForecastDay;
