import React from "react";
import ForecastDay from "./ForcastDay";

export interface ForecastProps {
  location: string;
}

const Forecast: React.FC<ForecastProps> = ({ location }) => {
  return (
    <div className="container">
      <h1>Forecast for {location}</h1>

      <div className="forecast-row">
        <ForecastDay
          date="Mon, Nov 3"
          condition="Sunny"
          highTemp={72}
          lowTemp={50}
          icon="https://cdn.weatherapi.com/weather/64x64/day/113.png"
        />
        <ForecastDay
          date="Tue, Nov 4"
          condition="Partly Cloudy"
          highTemp={68}
          lowTemp={49}
          icon="https://cdn.weatherapi.com/weather/64x64/day/116.png"
        />
        <ForecastDay
          date="Wed, Nov 5"
          condition="Light Rain"
          highTemp={64}
          lowTemp={47}
          icon="https://cdn.weatherapi.com/weather/64x64/day/296.png"
        />
      </div>
    </div>
  );
};

export default Forecast;
