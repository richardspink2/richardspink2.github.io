import "./App.css";
import Forecast from "./components/Forcast";

function App() {
  return (
    <div className="App">
      <Forecast location="Boise, ID" />
    </div>
  );
}

export default App;
