import { createRoot } from "react-dom/client";
import React from "react";
import Forecast from "./components/Forcast";
import App from "./App.tsx";

const rootElement = document.getElementById("root");

if (!rootElement) {
  throw new Error("Failed to find the root element to render the React app.");
}

const root = createRoot(rootElement);

root.render(
  <React.StrictMode>
    <Forecast location="Boise, Idaho" />
  </React.StrictMode>
);
