import React from "react";
import "./App.css";
import type { Todo } from "./assets/components/models/Todo";
import TodoList from "./assets/components/TodoList";

const App: React.FC = () => {
  const todoItems: Todo[] = [
    { id: "1", label: "Finish React lab", isComplete: false },
    { id: "2", label: "Study for quiz", isComplete: true },
    { id: "3", label: "Buy groceries", isComplete: false },
    { id: "4", label: "Learn TypeScript", isComplete: false },
    { id: "5", label: "Learn JavaScript", isComplete: false },
    { id: "6", label: "Learn SQL", isComplete: false },
  ];

  return (
    <div className="App">
      <h1>React Todo List</h1>
      <TodoList items={todoItems} />
    </div>
  );
};

export default App;
