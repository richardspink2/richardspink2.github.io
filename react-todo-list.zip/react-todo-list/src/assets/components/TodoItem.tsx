import React from "react";

interface TodoItemProps {
  id: string;
  label: string;
  isComplete: boolean;
  toggle: (id: string) => void;
}

const TodoItem: React.FC<TodoItemProps> = ({
  id,
  label,
  isComplete,
  toggle,
}) => {
  return (
    <div className="todo-item">
      <span
        className={`todo-label ${isComplete ? "completed" : ""}`}
        onClick={() => toggle(id)}
      >
        {label}
      </span>
      <button onClick={() => toggle(id)}>
        {isComplete ? "Undo" : "Complete"}
      </button>
    </div>
  );
};

export default TodoItem;
