export interface Todo {
  id: string;
  label: string;
  isComplete: boolean;
}
