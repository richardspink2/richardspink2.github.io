import React, { useState } from "react";
import type { Todo } from "./models/Todo";
import TodoItem from "./TodoItem";

interface TodoListProps {
  items: Todo[];
}

const TodoList: React.FC<TodoListProps> = ({ items }) => {
  const [todos, setTodos] = useState<Todo[]>(items);

  const toggle = (id: string) => {
    const updated = todos.map((todo) =>
      todo.id === id ? { ...todo, isComplete: !todo.isComplete } : todo
    );
    setTodos(updated);
  };

  return (
    <div className="todo-list">
      <h2>Buttons are better than check boxes </h2>
      {todos.map((todo) => (
        <TodoItem
          key={todo.id}
          id={todo.id}
          label={todo.label}
          isComplete={todo.isComplete}
          toggle={toggle}
        />
      ))}
    </div>
  );
};

export default TodoList;
