class Forecast {
  constructor(dayData) {
    this._condition = data.current.condition.text;
    this._icon = dayData.day.condition.icon;
    this._highTemp = dayData.day.maxtemp_f;
    this._lowTemp = dayData.day.mintemp_f;
    this._date = dayData.date;
  }

  get condition() {
    return this._condition;
  }

  get icon() {
    return this._icon;
  }

  get highTemp() {
    return this._highTemp;
  }

  get lowTemp() {
    return this._lowTemp;
  }

  get date() {
    return this._date;
  }
}

export default Forecast;
