import { useEffect, useState } from "react";
import "./App.css";

function App() {
  const [message, setMessage] = useState("");

  useEffect(() => {
    const getMessage = async () => {
      const response = await fetch("/api/hello");
      const json = await response.json();
      setMessage(json.message);
    };

    getMessage();
  }, []);

  return (
    <>
      <div>{message}</div>
    </>
  );
}

export default App;
