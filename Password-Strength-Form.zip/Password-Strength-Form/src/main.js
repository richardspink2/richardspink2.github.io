function validatePassword(password) {
  const errors = [];
  const specialChars = /[!@#$%^&*()_+{}\[\]|\\\/<>?]/;

  if (password.length < 12) {
    errors.push("The password is too short.");
  }

  if (!/[A-Z]/.test(password)) {
    errors.push("The password should contain an uppercase character.");
  }

  if (!/[a-z]/.test(password)) {
    errors.push("The password should contain a lowercase character.");
  }

  if (!/\d/.test(password)) {
    errors.push("The password should contain a number.");
  }

  if (!specialChars.test(password)) {
    errors.push("The password should contain a special character.");
  }

  if (/password/i.test(password)) {
    errors.push("The password should not contain the word 'Password'.");
  }

  return errors;
}

function passwordStrength(password) {
  let totalPoints = 0;

  if (password.length === 0) {
    return 0;
  }

  if (password.length >= 12) {
    totalPoints += 30;
  }

  let hasUppercase = false;
  let hasLowercase = false;
  let hasNumber = false;
  let hasSpecialChar = false;
  const specialChars = "!@#$%^&*()_+{}[]|\\/<>?";
  const numbers = "0123456789";

  for (const char of password) {
    if (char >= "A" && char <= "Z") {
      hasUppercase = true;
    } else if (char >= "a" && char <= "z") {
      hasLowercase = true;
    } else if (numbers.includes(char)) {
      hasNumber = true;
    } else if (specialChars.includes(char)) {
      hasSpecialChar = true;
    }
  }

  if (hasUppercase) totalPoints += 10;
  if (hasLowercase) totalPoints += 10;
  if (hasNumber) totalPoints += 10;
  if (hasSpecialChar) totalPoints += 10;

  const lowercasedPassword = password.toLowerCase();
  if (!lowercasedPassword.includes("password")) {
    totalPoints += 30;
  }

  return Math.min(totalPoints, 100);
}

document.addEventListener("DOMContentLoaded", () => {
  const passwordInput = document.getElementById("password");
  const errorsList = document.getElementById("errors");
  const strengthLabel = document.querySelector('label[for="strength"]');
  const strengthProgress = document.getElementById("strength");
  const pwdForm = document.getElementById("pwdForm");

  if (passwordInput && strengthLabel && strengthProgress) {
    passwordInput.addEventListener("input", () => {
      const password = passwordInput.value;
      const score = passwordStrength(password);
      strengthProgress.value = score;
      strengthLabel.innerHTML = score;
    });
  }

  if (pwdForm && passwordInput && errorsList) {
    pwdForm.addEventListener("submit", (event) => {
      const password = passwordInput.value;
      const errors = validatePassword(password);

      errorsList.innerHTML = "";

      if (errors.length > 0) {
        event.preventDefault();
        errorsList.style.color = "red";
        errors.forEach((errorText) => {
          const li = document.createElement("li");
          li.textContent = errorText;
          errorsList.appendChild(li);
        });
      } else {
        event.preventDefault();
        const li = document.createElement("li");
        li.textContent = "Good Password";
        errorsList.appendChild(li);
        errorsList.style.color = "green";
      }
    });
  }
});
