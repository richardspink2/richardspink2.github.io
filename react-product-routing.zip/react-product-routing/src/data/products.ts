export const products = [
  {
    id: 1,
    name: "Basil-infused Olive Oil",
    description: "Extra virgin olive oil infused with fresh basil.",
    price: 6.99,
  },
  {
    id: 2,
    name: "Coconut Chia Pudding",
    description:
      "Creamy chia pudding made with coconut milk and topped with mango.",
    price: 3.49,
  },
  {
    id: 3,
    name: "Foldable Yoga Mat Carry Bag",
    description: "Durable bag for carrying your yoga mat and accessories.",
    price: 18.99,
  },
  {
    id: 4,
    name: "Olive Oil",
    description: "Extra virgin olive oil, ideal for cooking and salads.",
    price: 7.99,
  },
  {
    id: 5,
    name: "Ice Cream Maker",
    description: "Homemade ice cream maker for delicious desserts.",
    price: 79.99,
  },
  {
    id: 6,
    name: "Glass Food Containers",
    description: "BPA-free glass containers for safe food storage.",
    price: 34.99,
  },
  {
    id: 7,
    name: "Vegetable Potstickers",
    description:
      "Delicious vegetable dumplings, perfect for steaming or frying.",
    price: 5.99,
  },
  {
    id: 8,
    name: "Maple Almond Yogurt",
    description: "Creamy yogurt made with maple and almond flavors.",
    price: 1.89,
  },
  {
    id: 9,
    name: "Electric Meat Grinder",
    description: "Powerful grinder for making sausage and burgers at home.",
    price: 89.99,
  },
  {
    id: 10,
    name: "Interactive Plush Toy",
    description: "Soft, cuddly toy that interacts with children.",
    price: 34.99,
  },
  {
    id: 11,
    name: "Organic Honeycrisp Apples",
    description: "Sweet and crisp apples, perfect for snacking.",
    price: 1.99,
  },
  {
    id: 12,
    name: "Set of Silicone Cooking Utensils",
    description: "Non-stick utensils for safe and easy cooking.",
    price: 29.99,
  },
  {
    id: 13,
    name: "Dog Training Whistle",
    description: "High-frequency whistle for training your dog effectively.",
    price: 8.99,
  },
  {
    id: 14,
    name: "Dual Function Electric Skillet",
    description: "Skillet that can fry, grill, and sauté with ease.",
    price: 59.99,
  },
  {
    id: 15,
    name: "Ginger Turmeric Latte Mix",
    description: "A warming blend of ginger and turmeric for lattes.",
    price: 5.29,
  },
  {
    id: 16,
    name: "Cinnamon Sugar Tortilla Chips",
    description: "Crispy chips with a sweet twist, perfect for dipping.",
    price: 3.29,
  },
  {
    id: 17,
    name: "Wildflower Honey",
    description: "Natural honey sourced from wildflowers.",
    price: 4.99,
  },
  {
    id: 18,
    name: "Cinnamon Sugar Popcorn",
    description: "Sweet popcorn coated in a mixture of cinnamon and sugar.",
    price: 2.89,
  },
  {
    id: 19,
    name: "Freestanding Wine Rack",
    description: "Stylish wine rack to store and display bottles.",
    price: 79.99,
  },
  {
    id: 20,
    name: "Vegetable Pizza Rolls",
    description:
      "Frozen pizza rolls filled with vegetables and cheese, perfect for snacks.",
    price: 6.49,
  },
  {
    id: 21,
    name: "Magnetic Puzzle Board",
    description: "Magnetic puzzle assembly board for kids.",
    price: 24.99,
  },
  {
    id: 22,
    name: "Dog Walking Waist Pack",
    description:
      "Hands-free waist pack for carrying essentials while walking your dog.",
    price: 19.99,
  },
  {
    id: 23,
    name: "Antique Style Clock",
    description: "Nostalgic clock that adds charm to any room.",
    price: 39.99,
  },
  {
    id: 24,
    name: "Car Vacuum Cleaner",
    description: "Compact vacuum designed specifically for cleaning vehicles.",
    price: 39.99,
  },
  {
    id: 25,
    name: "Frozen Chicken Nuggets",
    description: "Crispy chicken nuggets for quick meals.",
    price: 4.49,
  },
  {
    id: 26,
    name: "Black Bean & Corn Salad",
    description:
      "A fresh salad made with black beans, corn, and a zesty dressing, great for summer cookouts.",
    price: 3.99,
  },
  {
    id: 27,
    name: "Creamy Tomato Basil Soup",
    description:
      "Rich and creamy tomato basil soup, perfect with a grilled cheese.",
    price: 3.29,
  },
  {
    id: 28,
    name: "Chicken Parmesan Dinner Kit",
    description:
      "A complete meal kit containing breaded chicken breast, marinara sauce, and pasta, perfect for a quick dinner.",
    price: 14.99,
  },
  {
    id: 29,
    name: "Organic Green Lentils",
    description: "Nutty flavored lentils, perfect for soups and salads.",
    price: 3.99,
  },
  {
    id: 30,
    name: "Air Purifier",
    description: "HEPA air purifier for clean indoor air.",
    price: 129.99,
  },
  {
    id: 31,
    name: "Outdoor Adventure Backpack",
    description: "Durable backpack for hiking or travel.",
    price: 59.99,
  },
  {
    id: 32,
    name: "Multi-Function Smartphone Holder",
    description: "Versatile holder that can be used on desks, cars, and more.",
    price: 12.99,
  },
  {
    id: 33,
    name: "Organic Spinach",
    description: "Fresh organic spinach, great for salads or cooking.",
    price: 2.99,
  },
  {
    id: 34,
    name: "Poppy Seed Dressing",
    description:
      "A light and tangy dressing with poppy seeds, perfect for salads.",
    price: 3.49,
  },
  {
    id: 35,
    name: "Maple Syrup",
    description: "Pure maple syrup for pancakes and more.",
    price: 6.99,
  },
  {
    id: 36,
    name: "Organic Coconut Oil",
    description:
      "Cold-pressed coconut oil, perfect for cooking, baking, or skin care.",
    price: 8.99,
  },
  {
    id: 37,
    name: "Maple Chipotle Glaze",
    description:
      "A sweet and spicy glaze that's perfect for grilling or marinades.",
    price: 3.49,
  },
  {
    id: 38,
    name: "Compost Bin",
    description: "Countertop compost bin for kitchen waste.",
    price: 29.99,
  },
  {
    id: 39,
    name: "Natural Peanut Butter",
    description: "Creamy peanut butter with no added sugar or oils.",
    price: 4.29,
  },
  {
    id: 40,
    name: "Fitness Resistance Bands Kit",
    description: "Set with various resistance bands for workouts.",
    price: 29.99,
  },
  {
    id: 41,
    name: "Smartphone Hand Grip",
    description:
      "Sturdy grip to hold your phone securely while taking selfies.",
    price: 9.99,
  },
  {
    id: 42,
    name: "Herb Seasoned Croutons",
    description: "Crunchy croutons with a blend of herbs for salads.",
    price: 2.99,
  },
  {
    id: 43,
    name: "Waffle Maker",
    description: "Make delicious waffles with this user-friendly device.",
    price: 39.99,
  },
  {
    id: 44,
    name: "Digital Meat Thermometer",
    description: "Instant-read thermometer for precise cooking temperatures.",
    price: 24.99,
  },
  {
    id: 45,
    name: "Fitness Jump Rope",
    description: "Durable jump rope for cardio workouts.",
    price: 15.99,
  },
  {
    id: 46,
    name: "Bamboo Bathtub Caddy",
    description:
      "Expandable caddy for holding books, phones, and snacks while in the bath.",
    price: 34.99,
  },
  {
    id: 47,
    name: "Faux Fur Throw Blanket",
    description: "Cozy faux fur blanket to add warmth and style to your home.",
    price: 39.99,
  },
  {
    id: 48,
    name: "Portable Solar Charger",
    description: "Solar-powered charger for smartphones and tablets.",
    price: 29.99,
  },
  {
    id: 49,
    name: "Fitness Resistance Bands",
    description: "Set of resistance bands for home workouts.",
    price: 29.99,
  },
  {
    id: 50,
    name: "Smart Wi-Fi Light Bulbs",
    description:
      "Energy-efficient LED bulbs that can be controlled via smartphone.",
    price: 19.99,
  },
];

export default products;
