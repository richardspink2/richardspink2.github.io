import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Products from "./components/Products";
import Detail from "./components/Details";
import Search from "./components/Search";

function App() {
  return (
    <Router>
      <div>
        <h1>Product Routing App</h1>
        <nav>
          <Link to="/">Home</Link> | <Link to="/search">Search</Link>
        </nav>

        <Routes>
          <Route path="/" element={<Products />} />
          <Route path="/detail/:id" element={<Detail />} />
          <Route path="/search" element={<Search />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
