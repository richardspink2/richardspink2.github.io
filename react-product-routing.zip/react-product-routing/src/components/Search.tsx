import { useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { products } from "../data/products";

function Search() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [term, setTerm] = useState(searchParams.get("q") || "");

  const filtered = products.filter(
    (p) =>
      p.name.toLowerCase().includes(term.toLowerCase()) ||
      p.description.toLowerCase().includes(term.toLowerCase())
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ q: term });
  };

  return (
    <div>
      <h2>Search Products</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Search term"
          value={term}
          onChange={(e) => setTerm(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      <ul>
        {filtered.map((p) => (
          <Link
            to={`/detail/${p.id}`}
            key={p.id}
            style={{ textDecoration: "none" }}
          >
            <li>
              <strong>{p.name}</strong>
            </li>
          </Link>
        ))}
      </ul>
    </div>
  );
}

export default Search;
