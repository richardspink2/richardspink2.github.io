import { Link } from "react-router-dom";
import { products } from "../data/products";

function Products() {
  return (
    <div>
      <h2>Home</h2>
      <p>Click a product to view details:</p>
      <ul>
        {products.map((p) => (
          <Link
            to={`/detail/${p.id}`}
            key={p.id}
            style={{ textDecoration: "none" }}
          >
            <li>
              <strong>{p.name}</strong>
            </li>
          </Link>
        ))}
      </ul>
    </div>
  );
}

export default Products;
