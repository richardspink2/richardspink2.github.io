class Tester {
  validatePassword(password) {
    const errors = [];

    if (password.length < 12) {
      errors.push("The password is too short.");
    }

    if (!/[A-Z]/.test(password)) {
      errors.push("The password should contain an uppercase character.");
    }

    if (!/[a-z]/.test(password)) {
      errors.push("The password should contain a lowercase character.");
    }

    if (!/\d/.test(password)) {
      errors.push("The password should contain a number.");
    }

    if (!/[!@#$%^&*()_+{}\[\]|\\\/<>]/.test(password)) {
      errors.push("The password should contain a special character.");
    }

    if (password.toLowerCase().includes("password")) {
      errors.push("The password should not contain the word 'Password'.");
    }

    return errors;
  }
}

export default Tester;
