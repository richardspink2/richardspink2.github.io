import { useEffect, useState } from "react";
import { Container, Form, Button, Alert } from "react-bootstrap";
import WeatherCard from "./components/weatherCard";
import { type WeatherData } from "./types";

export default function App() {
  const [zip, setZip] = useState(localStorage.getItem("zip") || "");
  const [weather, setWeather] = useState<WeatherData | null>(null);
  const [error, setError] = useState("");
  const [isInvalid, setIsInvalid] = useState(false);

  useEffect(() => {
    if (zip.length === 5) fetchWeather(zip);
  }, [zip]);

  async function fetchWeather(zipCode: string) {
    try {
      const res = await fetch(
        `http://api.weatherapi.com/v1/forecast.json?key=cb0af4d1904c4574b2a194957252710&days=3&q=${zipCode}`
      );
      if (!res.ok) throw new Error("Invalid ZIP code");
      const data = await res.json();
      setWeather(data);
      setError("");
      localStorage.setItem("zip", zipCode);
    } catch (err: any) {
      setError(err.message);
      setWeather(null);
    }
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!/^\d{5}$/.test(zip)) {
      setIsInvalid(true);
      setError("Enter a valid 5-digit ZIP code");
      return;
    }
    setIsInvalid(false);
    fetchWeather(zip);
  };

  return (
    <div className="bg-dark text-white min-vh-100 d-flex justify-content-center align-items-start pt-4 w-100">
      <Container className="text-center" style={{ maxWidth: "450px" }}>
        <h1 className="mb-4">Weather Forecast</h1>

        <Form onSubmit={handleSubmit}>
          <Form.Group controlId="zipCode">
            <Form.Label>Enter ZIP Code</Form.Label>
            <Form.Control
              type="text"
              value={zip}
              onChange={(e) => setZip(e.target.value)}
              isInvalid={isInvalid}
              placeholder="e.g. 83651"
            />
            <Form.Control.Feedback type="invalid">
              {error}
            </Form.Control.Feedback>
          </Form.Group>

          <Button variant="primary" type="submit" className="mt-3 w-100">
            Get Forecast
          </Button>
        </Form>

        {error && !isInvalid && (
          <Alert variant="danger" className="mt-3">
            {error}
          </Alert>
        )}

        {weather && <WeatherCard weather={weather} />}
      </Container>
    </div>
  );
}
