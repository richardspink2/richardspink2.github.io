export interface WeatherData {
  location: {
    name: string;
    region: string;
  };
  current: {
    temp_f: number;
    humidity: number;
    condition: {
      text: string;
      icon: string;
    };
  };
  forecast: {
    forecastday: {
      date: string;
      day: {
        maxtemp_f: number;
        mintemp_f: number;
        condition: {
          text: string;
          icon: string;
        };
      };
    }[];
  };
}
