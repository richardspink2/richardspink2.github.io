import { Card, Row, Col } from "react-bootstrap";
import { type WeatherData } from "../types";

interface Props {
  weather: WeatherData;
}

export default function WeatherCard({ weather }: Props) {
  return (
    <Card className="text-center shadow-sm mt-4 bg-dark text-light p-3">
      <Card.Body>
        <Card.Title className="mb-3">
          {weather.location.name}, {weather.location.region}
        </Card.Title>

        <img
          src={weather.current.condition.icon}
          alt={weather.current.condition.text}
        />
        <p>
          <strong>{weather.current.condition.text}</strong>
        </p>
        <p>
          Temp: {weather.current.temp_f}°F | Humidity:{" "}
          {weather.current.humidity}%
        </p>

        <hr />

        <h5>3-Day Forecast</h5>
        <Row className="g-3">
          {weather.forecast.forecastday.map((day) => (
            <Col key={day.date} xs={12} md={4} className="d-flex">
              <Card className="bg-secondary text-light flex-fill text-center p-2">
                <Card.Text className="fw-bold">{day.date}</Card.Text>
                <img
                  src={day.day.condition.icon}
                  alt={day.day.condition.text}
                  className="mx-auto"
                />
                <Card.Text>{day.day.condition.text}</Card.Text>
                <Card.Text>
                  {day.day.mintemp_f}°F – {day.day.maxtemp_f}°F
                </Card.Text>
              </Card>
            </Col>
          ))}
        </Row>
      </Card.Body>
    </Card>
  );
}
