import { useState } from "react";
import "./App.css";
import { Container, Form, Button, Alert, Card } from "react-bootstrap";

export default function App() {
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");

  const [errors, setErrors] = useState({
    username: "",
    email: "",
    firstName: "",
    lastName: "",
  });

  const [alertMessage, setAlertMessage] = useState("");
  const [alertVariant, setAlertVariant] = useState<"success" | "danger">(
    "success"
  );

  function validateForm() {
    const newErrors = {
      username: "",
      email: "",
      firstName: "",
      lastName: "",
    };

    if (username.trim().length < 3) {
      newErrors.username = "Username must be at least 3 characters.";
    }
    if (!email.includes("@") || !email.includes(".")) {
      newErrors.email = "Please enter a valid email.";
    }
    if (firstName.trim().length === 0) {
      newErrors.firstName = "First name is required.";
    }
    if (lastName.trim().length === 0) {
      newErrors.lastName = "Last name is required.";
    }

    setErrors(newErrors);

    return (
      !newErrors.username &&
      !newErrors.email &&
      !newErrors.firstName &&
      !newErrors.lastName
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (!validateForm()) return;

    try {
      const response = await fetch("http://localhost:3000/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          email,
          firstName,
          lastName,
        }),
      });

      const data = await response.json();

      setAlertVariant(response.ok ? "success" : "danger");
      setAlertMessage(data.message || "Unknown server response.");
    } catch (err) {
      setAlertVariant("danger");
      setAlertMessage("Failed to reach the server.");
    }
  }

  return (
    <Container className="mt-5" style={{ maxWidth: "500px" }}>
      <Card className="p-4 shadow">
        <h2 className="mb-4 text-center">User Registration</h2>

        {alertMessage && <Alert variant={alertVariant}>{alertMessage}</Alert>}

        <Form onSubmit={handleSubmit}>
          {/* Username */}
          <Form.Group className="mb-3">
            <Form.Label>Username</Form.Label>
            <Form.Control
              type="text"
              value={username}
              isInvalid={!!errors.username}
              onChange={(e) => setUsername(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              {errors.username}
            </Form.Control.Feedback>
          </Form.Group>

          {/* Email */}
          <Form.Group className="mb-3">
            <Form.Label>Email Address</Form.Label>
            <Form.Control
              type="email"
              value={email}
              isInvalid={!!errors.email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              {errors.email}
            </Form.Control.Feedback>
          </Form.Group>

          {/* First Name */}
          <Form.Group className="mb-3">
            <Form.Label>First Name</Form.Label>
            <Form.Control
              type="text"
              value={firstName}
              isInvalid={!!errors.firstName}
              onChange={(e) => setFirstName(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              {errors.firstName}
            </Form.Control.Feedback>
          </Form.Group>

          {/* Last Name */}
          <Form.Group className="mb-3">
            <Form.Label>Last Name</Form.Label>
            <Form.Control
              type="text"
              value={lastName}
              isInvalid={!!errors.lastName}
              onChange={(e) => setLastName(e.target.value)}
            />
            <Form.Control.Feedback type="invalid">
              {errors.lastName}
            </Form.Control.Feedback>
          </Form.Group>

          {/* Submit */}
          <Button type="submit" variant="primary" className="w-100">
            Register
          </Button>
        </Form>
      </Card>
    </Container>
  );
}
