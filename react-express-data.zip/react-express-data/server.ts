import express from "express";
import cors from "cors";

const PORT = process.env.PORT || 3000;
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  if (req.method === "POST") {
    console.log("POST Request Body:", req.body);
  }
  next();
});

app.post("/api/register", (req, res) => {
  const { username, email, firstName, lastName } = req.body;

  if (!username || username.trim().length < 3) {
    return res
      .status(400)
      .json({ message: "Username must be at least 3 characters." });
  }

  if (!email || !email.includes("@") || !email.includes(".")) {
    return res
      .status(400)
      .json({ message: "Please enter a valid email address." });
  }

  if (!firstName || firstName.trim().length === 0) {
    return res.status(400).json({ message: "First name is required." });
  }

  if (!lastName || lastName.trim().length === 0) {
    return res.status(400).json({ message: "Last name is required." });
  }

  // If everything is good — return success
  return res.json({
    message: `User "${username}" registered successfully!`,
  });
});

// ---- Server Start ----
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
